<?php
include("checksession.php");
include("config.php");
header('Content-Type: application/json');

$tp_id = (int)($_GET['tp_id'] ?? 0);
if (!$tp_id) { echo json_encode(['has_stock' => false]); exit; }

$stmt = $db_conn->prepare("SELECT COUNT(*) AS n FROM territory_partner_stock_ledger WHERE territory_partner_id = ? AND ref_type = 'manual_input'");
$stmt->bind_param("i", $tp_id);
$stmt->execute();
$n = (int)$stmt->get_result()->fetch_assoc()['n'];
$stmt->close();

echo json_encode(['has_stock' => $n > 0]);
