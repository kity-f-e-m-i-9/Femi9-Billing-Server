<?php include("checksession.php");

$title="Update Category (Distributor)";
$manage_url="cat-view-dt";
$manage_title="Manage Category (Distributor)";
$message_title="Category (Distributor)";

$prid=$_REQUEST['prid'];
$prid=base64_decode($prid);

//fetch product details
$select_product_list="select * from distributor_category where id='$prid'";
										$fetch_product_list=mysqli_query($db_conn,$select_product_list);
									$result_product_list=mysqli_fetch_array($fetch_product_list);
									
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <!-- Title -->
    <title><?php echo $title;?> : <?php echo $business_name;?></title>

    <!-- Styles -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
    <link href="../../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/plugins/perfectscroll/perfect-scrollbar.css" rel="stylesheet">
    <link href="../../assets/plugins/pace/pace.css" rel="stylesheet">
    <link href="../../assets/plugins/highlight/styles/github-gist.css" rel="stylesheet">


    <!-- Theme Styles -->
    <link href="../../assets/css/main.min.css" rel="stylesheet">
    <link href="../../assets/css/custom.css" rel="stylesheet">

    <link rel="icon" type="image/png" sizes="32x32" href="../../assets/images/neptune.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/neptune.png" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body>
    <div class="app align-content-stretch d-flex flex-wrap">
        <div class="app-sidebar">
            <?php include("logo.php");?>
            <?php include("femi_menu.php");?>
        </div>
        <div class="app-container">
           
          <?php include("app-header.php");?>
			
            <div class="app-content">
                <div class="content-wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col">
                                <div class="page-description">
                                     <h1>
									<table class="headertble">
									<tr>
									<td><?php echo $title;?></td>
									<td><a href="<?php echo $manage_url;?>" title="<?php echo $manage_title;?>">&#9776;</a></td>
									</tr>
									</table>
									</h1>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <!----<div class="card-header">
                                        <h5 class="card-title">Basic Input</h5>
                                    </div>--->
                                    <div class="card-body">
                                        <?php if(isset($_REQUEST['alreadyexists'])){?><div class="alert alert-danger"><?php echo $message_title;?> already exists !</div><?php }?>
 <?php include("validate-scripts.php");?>                                      
<form action="product-action" method="post" enctype="multipart/form-data">

<input type="hidden" name="update_id" value="<?php echo $result_product_list["id"]?>">
<input type="hidden" name="prid" value="<?php echo $prid?>">

                                        <div class="example-container">
                                            <div class="example-content">
                                                
												<label for="exampleInputEmail1" class="form-label">Category</label>
                                                <input type="text" required="" name="catname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onkeypress="restrictCountryName(event)" value="<?=$result_product_list['name'];?>">
												<br/>
												
												<label for="exampleInputEmail1" class="form-label">Target Sales Value(Rs.)</label>
                                                <input type="number" min="0" onkeypress="restrictnumber(event)" class="form-control" name="target_amount" value="<?=$result_product_list['amount'];?>" required="required" max="999999" placeholder="Target Amount(Rs.)"/>
												<br/>
												
												<label for="exampleInputEmail1" class="form-label">Referral (%)</label>
                                                <input type="number" value="<?=$result_product_list['ref_commission_percentage'];?>" onkeypress="restrictnumber(event)" class="form-control" name="ref_commission_percentage" min="0" max="10" required="required" placeholder="Referral(%)"/>
												<br/>
												
												<label for="exampleInputEmail1" class="form-label">Cashback (%)</label>
                                                <input type="number" onkeypress="restrictnumber(event)" class="form-control" name="cash_back_percentage" min="0" max="10" required="required" placeholder="Referral(%)" value="<?=$result_product_list['cash_back_percentage'];?>"/>
												<br/>
												
												<button type="submit" name="UpdateDistributorCategory" class="btn btn-primary">Update</button>
												
                                            </div>
											
                                        </div>
										
										</form>
										
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascripts -->
    <script src="../../assets/plugins/jquery/jquery-3.5.1.min.js"></script>
    <script src="../../assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="../../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="../../assets/plugins/perfectscroll/perfect-scrollbar.min.js"></script>
    <script src="../../assets/plugins/pace/pace.min.js"></script>
    <script src="../../assets/plugins/highlight/highlight.pack.js"></script>
    <script src="../../assets/js/main.min.js"></script>
    <script src="../../assets/js/custom.js"></script>
</body>
</html>